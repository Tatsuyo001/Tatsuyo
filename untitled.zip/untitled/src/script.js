// Add interactivity
document.querySelectorAll('.cta-button').forEach(button => {
  button.addEventListener('click', function (e) {
    e.preventDefault();
    alert("Thank you for your interest! You're one step closer to winning.");
  });
});